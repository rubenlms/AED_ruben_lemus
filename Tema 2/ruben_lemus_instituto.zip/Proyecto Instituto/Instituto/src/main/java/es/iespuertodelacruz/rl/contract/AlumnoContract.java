package es.iespuertodelacruz.rl.contract;

public abstract class AlumnoContract {
	

}
